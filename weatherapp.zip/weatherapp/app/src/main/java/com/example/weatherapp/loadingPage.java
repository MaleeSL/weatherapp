package com.example.weatherapp;

import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class loadingPage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_loading_page);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        ImageView spinningIcon = findViewById(R.id.progressBar);
        ObjectAnimator rotateAnimation = ObjectAnimator.ofFloat(spinningIcon, "rotation", 0f, 360f);
        rotateAnimation.setDuration(1500);
        rotateAnimation.setRepeatCount(ValueAnimator.INFINITE);
        rotateAnimation.setInterpolator(new android.view.animation.LinearInterpolator());
        rotateAnimation.start();

        // Animate Text Size
        TextView animatedText = findViewById(R.id.animatedText);
        ObjectAnimator textSizeAnimator = ObjectAnimator.ofFloat(animatedText, "textSize", 24f, 32f, 24f);
        textSizeAnimator.setDuration(1200);
        textSizeAnimator.setRepeatCount(ValueAnimator.INFINITE);
        textSizeAnimator.setRepeatMode(ValueAnimator.REVERSE);
        textSizeAnimator.start();

        new Handler().postDelayed(() -> {
            Intent intent = new Intent(loadingPage.this, loggingPage.class);
            startActivity(intent);
            finish();
        }, 3000);
    }
}